// A sample code for assignment #2 using C++ class
// HYONGJU PARK

#define ARRAY_SIZE(array) (sizeof((array))/sizeof((array[0])))

#include <ros/ros.h>
#include <iostream>     			// to use: std::cout, std::cin, etc
#include <cmath>					// to use: atan2, sqrt, pow, etc
#include <iomanip>     				// to use: setprecision()
#include <geometry_msgs/Twist.h> 
#include <nav_msgs/Odometry.h>

#include <tf/transform_listener.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>

#include <boost/geometry/geometry.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <boost/geometry/geometries/polygon.hpp>
#include <boost/geometry/strategies/transform.hpp>
#include <boost/geometry/strategies/transform/matrix_transformers.hpp>	
#include <boost/geometry/io/wkt/wkt.hpp>
#include <boost/tuple/tuple.hpp>

// ros::Time::now() current time
// ros::Time(0) the most recent available time etc...
/*/////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////*/
// THIS IS THE TURTLE CLASS

//using boost::geometry::dsv;
typedef boost::geometry::model::d2::point_xy<double> point_type;
typedef boost::geometry::model::polygon<point_type> poly_type;
typedef boost::geometry::model::linestring<point_type> linestring_type;
typedef boost::tuple<double, double, double> tuple3;
std::string base_footprint;



// WE NEED A NEW BROADCASTER FROM ODOM TO BASE_FOOTPRINT (this does not exists...)

void OdomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
	tf::TransformBroadcaster br;
	tf::Pose pose_base;
	tf::poseMsgToTF(msg->pose.pose, pose_base);
	br.sendTransform(tf::StampedTransform(pose_base,ros::Time::now(),"odom","base_footprint"));
}


// This function calculates the distance between point and a polygon obstacle
tuple3 obstacleDistance(const point_type &p1, const poly_type &obs1)
{
	double x[obs1.outer().size()];
	double y[obs1.outer().size()];
	double dmin = 10000;
	double x1 = 0.0, y1 = 0.0;
	double dist_min[obs1.outer().size()-1];
	
	// THIS IS THE OBSTACLE ---- CHECKING ALL THE OURTER RIMS (VERTICES)
	for (unsigned i = 0; i != obs1.outer().size(); ++i) {
		x[i] = boost::geometry::get<0>(obs1.outer()[i]);
		y[i] = boost::geometry::get<1>(obs1.outer()[i]);
		//std::cout << " " << x[i];
		//std::cout << " " << y[i];
		point_type xy(x[i],y[i]);
		double dmin_tmp = boost::geometry::distance(p1,xy);
		if (dmin_tmp <= dmin)
		{
			dmin = dmin_tmp;
			x1 = x[i];
			y1 = y[i];
		}
	}
	for (unsigned i = 0; i != obs1.outer().size()-1; ++i) {
		linestring_type line;
		line.push_back(point_type(x[i],y[i]));
		line.push_back(point_type(x[i+1],y[i+1]));	
		dist_min[i] = boost::geometry::distance(p1, line);
		if (dist_min[i] < dmin)
		{
			point_type p1t(x[i],y[i]);
			point_type p2t(x[i+1],y[i+1]);
			double d_p1_p1t = boost::geometry::distance(p1, p1t);
			double d_p1_p2t = boost::geometry::distance(p1, p2t);
			double d_p1t_p2t = boost::geometry::distance(p1t, p2t);
			double d_p1t_x = sqrt(pow(d_p1_p1t,2) - pow(dist_min[i],2));
			x1 = d_p1t_x * (x[i+1] - x[i])/d_p1t_p2t + x[i];
			y1 = d_p1t_x * (y[i+1] - y[i])/d_p1t_p2t + y[i];
			dmin = dist_min[i];
		}
	}
	return tuple3(dmin, x1, y1);
}

tf::Stamped<tf::Pose> odomtobase(const double & pgx,const double & pgy, const tf::TransformListener& listener)
{
	tf::Stamped<tf::Pose> goal_pose(
	tf::Pose(tf::Quaternion(0,0,0,1), tf::Vector3(pgx,pgy,0.0)),
	ros::Time(0), "odom");
	tf::Stamped<tf::Pose> tf_goal_pose;
	listener.transformPose(base_footprint,goal_pose, tf_goal_pose);
	return tf_goal_pose;
}
/*/////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////*/
// MAIN FUNCTION

int main(int argc, char **argv)
{
	// here's the actual name for the base_footprint
	base_footprint = "base_footprint";

	// create node 'sample_node' (ros::init_options::NoSigintHandler works file for no reason, 
	// I need to figure out, without it if you try Ctrl+C at cin, it won't work...) 
	// DEFINE FIXED QUANTITIES....
	/////////////////////////////////////////
	
	// INITIALIZE YOUR ROBOT HERE...
	poly_type youbot;
	
	//std::string const plg = "POLYGON((-0.3 0.2, 0.3 0.2, 0.3 -0.2, -0.3 -0.2, -0.3 0.2))";  
	boost::geometry::read_wkt("POLYGON((-0.3 0.2, 0.3 0.2, 0.3 -0.2, -0.3 -0.2, -0.3 0.2))",youbot);
	
	//std::cout << dsv(youbot) << std::endl;
	//std::cout << youbot.outer().size() << std::endl;
	double yb_x[youbot.outer().size()-1];
	double yb_y[youbot.outer().size()-1];
	for (unsigned i = 0; i != youbot.outer().size()-1; ++i) {
		yb_x[i] = boost::geometry::get<0>(youbot.outer()[i]);
		yb_y[i] = boost::geometry::get<1>(youbot.outer()[i]);
	}	

	// INITIALIZE YOUR OBSTACLES HERE...
	// obstacle
	const unsigned int NUMBER_OF_OBSTACLES = 5;
	poly_type obs[NUMBER_OF_OBSTACLES];
	
	boost::geometry::read_wkt("POLYGON((-3.5 3.5, -3.5 -3.5, 3.5 -3.5, 3.5 3.5, -3.5 3.5))", obs[0]);
	boost::geometry::read_wkt("POLYGON((-0.5 0.5, 0.5 0.5, 0.5 -0.5, -0.5 -0.5, -0.5 0.5))", obs[1]);    
	boost::geometry::read_wkt("POLYGON((-0.375 0.375, 0.375 0.375, 0.375 -0.375, -0.375 -0.375, -0.375 0.375))", obs[2]);    
	boost::geometry::read_wkt("POLYGON((-0.25 0.25, 0.25 0.25, 0.25 -0.25, -0.25 -0.25, -0.25 0.25))", obs[3]);    
	boost::geometry::read_wkt("POLYGON((-0.125 0.125, 0.125 0.125, 0.125 -0.125, -0.125 -0.125, -0.125 0.125))", obs[4]);    

	double trans[NUMBER_OF_OBSTACLES][2] = {{2.5,2.5},{2.5,2.5},{5,1},{3,5},{0,3.0}};
	
	poly_type obs_tr[NUMBER_OF_OBSTACLES];	
	for (unsigned i = 0; i != NUMBER_OF_OBSTACLES; ++i) {
		boost::geometry::strategy::transform::translate_transformer<point_type, point_type> translate(trans[i][0],trans[i][1]);
		boost::geometry::transform(obs[i], obs_tr[i], translate);
    }

	//boost::geometry::transform(obs[0], obs_tr[0], translate);

    ///////////////
    // YOUR OBSTACLE IS 'obs1'

	////////////////////////////////////////////
	////////////////////////////////////////////
	////////////////////////////////////////////
	// Initilization ROS...

    ros::init(argc, argv,"sample_node",ros::init_options::NoSigintHandler);  
    ros::NodeHandle n;	
	// create node handle
	ros::Publisher pub = n.advertise<geometry_msgs::Twist>("cmd_vel",10);
	ros::Subscriber sub = n.subscribe("odom", 100, OdomCallback);
	ros::Rate loop_rate(10);
	
	
	
	////////////////////////////////////////////
	
	/////////////////////////
	// TF lister
	
	// what we want here
	// --> youbot's origin and corners in world coordinate frame...
	// we will set the relation here
	// actual data will be set using transformPose() from listener
		
	tf::TransformListener listener;
	
	// Stamped ----> with frameid for youbot.....
	// corner #1
	tf::Stamped<tf::Pose> yb_origin((tf::Pose(tf::Quaternion(0,0,0,1), tf::Vector3(0,0,0.0))),
		ros::Time(0),base_footprint);	
	tf::Stamped<tf::Pose> yb_corner[youbot.outer().size()-1];
	tf::Stamped<tf::Pose> tf_yb_origin;
	tf::Stamped<tf::Pose> tf_yb_corner[youbot.outer().size()-1];

	////// LET'S CREATE AUTOMATION....
	
	for (unsigned i = 0; i != youbot.outer().size()-1; ++i) {
		yb_corner[i].frame_id_ = base_footprint;
		yb_corner[i].stamp_ = ros::Time(0);
		yb_corner[i].setData(
			tf::Pose(tf::Quaternion(0,0,0,1), tf::Vector3(boost::geometry::get<0>(youbot.outer()[i]),boost::geometry::get<1>(youbot.outer()[i]),0.0)));		
	}
	

	
	////////////////////////////////////////////
	
	
	////////////////////////////////////////////
	////////////////////////////////////////////
	////////////////////////////////////////////
	// DECLARATIONS OF VARIABLES NEEDED FOR POTENTIAL FUNCTIONS, ETC
	const double eta1 = -0.1, eta2 = -0.01;
	const double d_star = 1.0, Q_star = 0.2;
	const double tol = 0.08;	
	double cpx = 0.0, cpy = 0.0, cpo = 0.0;
	double pgx = 10.0, pgy = 10.0;
	double pgx_tr, pgy_tr;
	double d_u_att_x = 0.0, d_u_att_y = 0.0, d_u_att_t = 0.0;
	double d_u_rep_x = 0.0, d_u_rep_y = 0.0, d_u_rep_t = 0.0;
	double dmin;
	double x1 = 0.0, y1 = 0.0;	
	double x1_tr = 0.0, y1_tr = 0.0;

	
	std::cout << "Enter your initial goal: ";
	std::cin >> pgx >> pgy;
	
	while(n.ok()){
		ros::spinOnce();	
		geometry_msgs::Twist vel;
		////////////////////////////////////////////////////////////////
		// READ ROBOT'S POSE AT ORIGIN, CONTROL POINTS
		for (unsigned i = 0; i != youbot.outer().size()-1; ++i) {
			listener.transformPose("odom",yb_corner[i], tf_yb_corner[i]);
			yb_x[i] = yb_corner[i].getOrigin().x();
			yb_y[i] = yb_corner[i].getOrigin().y(); // robot's corner positions in world coordinate frame
		}
		
		listener.transformPose("odom",yb_origin, tf_yb_origin); // robots' origin in world coordinate frame
		cpx = tf_yb_origin.getOrigin().x();
		cpy = tf_yb_origin.getOrigin().y();			
		cpo = tf::getYaw(tf_yb_origin.getRotation()); 
		////////////////////////////////////////////////////////////////
		
		if (std::abs(pgx - cpx) < tol && std::abs(pgy - cpy) < tol)
		{
			vel.linear.x = 0.0;
			vel.linear.y = 0.0;
			vel.angular.z = 0.0;			
			pub.publish(vel);
			std::cout << "Enter your new goal: " << std::endl;
			std::cin >> pgx >> pgy;
		}
		
		tf::Stamped<tf::Pose> tf_goal_pose = odomtobase(pgx,pgy,listener);
		//////// GOAL POSITION !!!!
		pgx_tr = tf_goal_pose.getOrigin().x();
		pgy_tr = tf_goal_pose.getOrigin().y();

				
		for (unsigned i = 0; i != youbot.outer().size()-1; ++i) 
		{
				
			// std::cout << "I AM IN THE LOOP" << std::endl;
			
			
			point_type p1(tf_yb_corner[i].getOrigin().x(), tf_yb_corner[i].getOrigin().y());
			

			////////////////////////////////////////////////////////////
			////////////////////////////////////////////////////////////
			// YOUR CODE SHOULD BEGIN HERE!
			
			
			// Attraction force...
			
			point_type rqg(pgx, pgy);
			double d_rq_rqg = boost::geometry::distance(p1, rqg);
		
			if (d_rq_rqg <= d_star)
			{
				d_u_att_x = eta1 * (yb_x[i] - pgx_tr);
				d_u_att_y = eta1 * (yb_y[i] - pgy_tr);
				
			}
			else
			{
				d_u_att_x = d_star * eta1 * (yb_x[i] - pgx_tr) / d_rq_rqg;
				d_u_att_y = d_star * eta1 * (yb_y[i] - pgy_tr) / d_rq_rqg;
			}
			d_u_att_t = -d_u_att_x *(yb_x[i]*sin(cpo)+yb_y[i]*cos(cpo)) + d_u_att_y * (yb_x[i]*cos(cpo)-yb_y[i]*sin(cpo));
			
			// Repulsive force...
			
			///////////////////////////// DISTANCE, CLOSEST POINT COMPUTATION IN WORLD (odom) COORDINATE
			for (unsigned j = 0; j != NUMBER_OF_OBSTACLES; ++j) 
			{
				tuple3 tp = obstacleDistance(p1,obs_tr[j]);
				dmin = tp.get<0>();
				x1 = tp.get<1>();
				y1 = tp.get<2>();
				if (j ==4 )
				{
					std::cout << dmin << " " << x1 << " " << y1;
				}					
				tf::Stamped<tf::Pose> tf_obs_pose = odomtobase(x1,y1,listener);
				x1_tr = tf_obs_pose.getOrigin().x();
				y1_tr = tf_obs_pose.getOrigin().y();
				if (dmin <= Q_star)
				{
					d_u_rep_x = eta2 * (1/Q_star - 1/dmin) / pow(dmin,2) * (yb_x[i]-x1_tr); 
					d_u_rep_y =	eta2 * (1/Q_star - 1/dmin) / pow(dmin,2) * (yb_y[i]-y1_tr);
				}
				else
				{
					d_u_rep_x = 0.0;
					d_u_rep_y = 0.0;
				}
				d_u_rep_t = -d_u_rep_x *(yb_x[i]*sin(cpo)+yb_y[i]*cos(cpo)) + d_u_rep_y * (yb_x[i]*cos(cpo)-yb_y[i]*sin(cpo));
				vel.linear.x += d_u_rep_x;
				vel.linear.y += d_u_rep_y;
				//vel.angular.z += d_u_rep_t;
										
			}			
			std::cout << std::endl;
			
			// Summation and trasformation
 
			vel.linear.x += (d_u_att_x);
			vel.linear.y += (d_u_att_y);
			//vel.angular.z += (d_u_att_t);

		}
		std::cout << "dist: " << std::setprecision(3) << dmin << " " << 
		"loc(x,y): (" << std::setprecision(3) << x1 << "," << std::setprecision(3) << y1 << ") " << "err(x,y): (" << std::setprecision(3) << pgx - cpx << "," << std::setprecision(3) << pgy - cpy << ")"<< std::endl;
		pub.publish(vel);
		loop_rate.sleep();
	}

	return 0;
}





