// A sample code for assignment #2 using C++ class
// HYONGJU PARK

#include <ros/ros.h>
#include <iostream>     			// to use: std::cout, std::cin, etc
#include <cmath>					// to use: atan2, sqrt, pow, etc
#include <iomanip>     				// to use: setprecision()
#include <geometry_msgs/Twist.h> 
#include <nav_msgs/Odometry.h>

#include <boost/geometry/geometry.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <boost/geometry/geometries/polygon.hpp>
#include <boost/geometry/strategies/transform.hpp>
#include <boost/geometry/strategies/transform/matrix_transformers.hpp>	
#include <boost/geometry/io/wkt/wkt.hpp>



/*/////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////*/
// THIS IS THE TURTLE CLASS

using boost::geometry::dsv;
typedef boost::geometry::model::d2::point_xy<double> point_type;
typedef boost::geometry::model::polygon<point_type> poly_type;
typedef boost::geometry::model::linestring<point_type> linestring_type;

nav_msgs::Odometry odom;


void OdomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
	odom.pose.pose.position.x = msg->pose.pose.position.x;
	odom.pose.pose.position.y = msg->pose.pose.position.y;
	odom.pose.pose.orientation.z = msg->pose.pose.orientation.z;
//	ROS_INFO("Seq: [%d]", msg->header.seq);
//	ROS_INFO("Position-> x: [%f], y: [%f], z: [%f]", msg->pose.pose.position.x,msg->pose.pose.position.y, msg->pose.pose.position.z);
//	ROS_INFO("Orientation-> x: [%f], y: [%f], z: [%f], w: [%f]", msg->pose.pose.orientation.x, msg->pose.pose.orientation.y, msg->pose.pose.orientation.z, msg->pose.pose.orientation.w);
//	ROS_INFO("Vel-> Linear: [%f], Angular: [%f]", msg->twist.twist.linear.x,msg->twist.twist.angular.z);
}


void test(poly_type yb)
{
}
/*/////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////*/
/*/////////////////////////////////////////////////////////////*/
// MAIN FUNCTION

int main(int argc, char **argv)
{
	// create node 'sample_node' (ros::init_options::NoSigintHandler works file for no reason, 
	// I need to figure out, without it if you try Ctrl+C at cin, it won't work...) 
	// DEFINE FIXED QUANTITIES....
	/////////////////////////////////////////
	
	// youbot
	poly_type youbot;
	boost::geometry::read_wkt("POLYGON((-0.3 0.2, 0.3 0.2, 0.3 -0.2, -0.3 -0.2, -0.3 0.2))",youbot);
	
	//std::cout << dsv(youbot) << std::endl;
	//std::cout << youbot.outer().size() << std::endl;
	double yb_x[youbot.outer().size()-1];
	double yb_y[youbot.outer().size()-1];
	for (unsigned i = 0; i != youbot.outer().size()-1; ++i) {
		yb_x[i] = boost::geometry::get<0>(youbot.outer()[i]);
		yb_y[i] = boost::geometry::get<1>(youbot.outer()[i]);
	}	

	// obstacle
	poly_type obs;
	boost::geometry::read_wkt("POLYGON((-1 1, 1 1, 1 -1, -1 -1, -1 1))", obs);    
	// translated obstacle: by (5,4)
	poly_type obs1;	
    boost::geometry::strategy::transform::translate_transformer<point_type, point_type> translate(5, 4);
    boost::geometry::transform(obs, obs1, translate);

	////////////////////////////////////////////
	////////////////////////////////////////////
	////////////////////////////////////////////
	// ROS STUFFS

    ros::init(argc, argv,"sample_node",ros::init_options::NoSigintHandler);  
    ros::NodeHandle n;	
	// create node handle
	ros::Publisher pub = n.advertise<geometry_msgs::Twist>("cmd_vel",10);
	ros::Subscriber sub = n.subscribe("odom", 100, OdomCallback);
	ros::Rate loop_rate(10);
	
	////////////////////////////////////////////
	////////////////////////////////////////////
	////////////////////////////////////////////
	// DECLARATIONS OF VARIABLES NEEDED FOR POTENTIAL FUNCTIONS, ETC
	const double eta1 = -0.2;
	const double eta2 = -2;
	const double d_star = 2;
	const double Q_star = 1;
	double cpx;
	double cpy;
	double cpo;
	double pgx = 10.0;
	double pgy = 10.0;
	double pgx_tr;
	double pgy_tr;
	double d_u_att_x = 0.0;
	double d_u_att_y = 0.0;
	double d_u_att_t = 0.0;
	double d_u_rep_x = 0.0;
	double d_u_rep_y = 0.0;
	double d_u_rep_t = 0.0;	
	double dmin;
	double x1;
	double y1;	
	double x1_tr;
	double y1_tr;
	const double tol = 0.02;
	std::cout << "Enter your initial goal: ";
	std::cin >> pgx >> pgy;
	while(n.ok()){
		ros::spinOnce();	// REACEIVE MSGS ("Odometry" in this case...)
		cpx = odom.pose.pose.position.x;
		cpy = odom.pose.pose.position.y;
		cpo = odom.pose.pose.orientation.z; 
		geometry_msgs::Twist vel;
		vel.linear.x = 0.0;
		vel.linear.y = 0.0;
		vel.angular.z = 0.0;
/*		if (abs(pgx - cpx) < tol && abs(pgy - cpy) < tol && abs(cpx) > tol && abs(cpy) > tol)
		{
			pgx = 0.0;
			pgy = 0.0;
		}
		*/
		//std::cout << std::abs(pgx - cpx) <<  std::abs(pgy - cpy) << std::endl;
		//std::cout << (std::abs(pgx - cpx) < tol && std::abs(pgy - cpy) < tol) << std::endl;
		if (std::abs(pgx - cpx) < tol && std::abs(pgy - cpy) < tol)
		{
			pub.publish(vel);
			std::cout << "Enter your new goal: " << std::endl;
			std::cin >> pgx >> pgy;
		}
		for (unsigned yi = 0; yi != youbot.outer().size()-1; ++yi) 
		{
				
			// std::cout << "I AM IN THE LOOP" << std::endl;
			
			point_type p1(cpx+cos(cpo)*yb_x[yi]-sin(cpo)*yb_y[yi], cpy+sin(cpo)*yb_x[yi]+cos(cpo)*yb_y[yi]);
			// Attraction force...
			point_type rqg(pgx, pgy);
			double d_rq_rqg = boost::geometry::distance(p1, rqg);
			//////////////////
			pgx_tr = (pgx-cpx)*cos(cpo) + (pgy-cpy)*sin(cpo);
			pgy_tr = -(pgx-cpx)*sin(cpo) + (pgy-cpy)*cos(cpo);
			//////////////////			
			if (d_rq_rqg <= d_star)
			{
				d_u_att_x = eta1 * (yb_x[yi] - pgx_tr);
				d_u_att_y = eta1 * (yb_y[yi] - pgy_tr);
				
			}
			else
			{
				d_u_att_x = d_star * eta1 * (yb_x[yi] - pgx_tr) / d_rq_rqg;
				d_u_att_y = d_star * eta1 * (yb_y[yi] - pgy_tr) / d_rq_rqg;
			}
			d_u_att_t = -d_u_att_x *(yb_x[yi]*sin(cpo)+yb_y[yi]*cos(cpo)) + d_u_att_y * (yb_x[yi]*cos(cpo)-yb_y[yi]*sin(cpo));
			// Repulsive force...
			//////////////////////////
			// input p1 ----------> 


		
			double x[obs1.outer().size()];
			double y[obs1.outer().size()];
			dmin = 10000;
			// THIS IS THE OBSTACLE CHECKING ALL THE OURTER RIMS (VERTICES)
			for (unsigned i = 0; i != obs1.outer().size(); ++i) {
				x[i] = boost::geometry::get<0>(obs1.outer()[i]);
				y[i] = boost::geometry::get<1>(obs1.outer()[i]);
				//std::cout << " " << x[i];
				//std::cout << " " << y[i];
				point_type xy(x[i],y[i]);
				double dmin_tmp = boost::geometry::distance(p1,xy);
				if (dmin_tmp <= dmin)
				{
					dmin = dmin_tmp;
					x1 = x[i];
					y1 = y[i];
				}
			}
			double dist_min[obs1.outer().size()-1];
			//	double dmin = boost::geometry::distance(p1,obs1);
			//	std::cout << " " << dmin;
			for (unsigned i = 0; i != obs1.outer().size()-1; ++i) {
				linestring_type line;
				line.push_back(point_type(x[i],y[i]));
				line.push_back(point_type(x[i+1],y[i+1]));	
				dist_min[i] = boost::geometry::distance(p1, line);
				//std::cout << " " << dist_min[i] ; 
				if (dist_min[i] < dmin)
				{
					point_type p1t(x[i],y[i]);
					point_type p2t(x[i+1],y[i+1]);
					double d_p1_p1t = boost::geometry::distance(p1, p1t);
					double d_p1_p2t = boost::geometry::distance(p1, p2t);
					double d_p1t_p2t = boost::geometry::distance(p1t, p2t);
					double d_p1t_x = sqrt(pow(d_p1_p1t,2) - pow(dist_min[i],2));
					x1 = d_p1t_x * (x[i+1] - x[i])/d_p1t_p2t + x[i];
					y1 = d_p1t_x * (y[i+1] - y[i])/d_p1t_p2t + y[i];
					dmin = dist_min[i];
				}
			}
			// INPUT ----------- p1
			// OUTPUT ----------- x1, y1, dmin
			//point_type min_pnt(x1,y1);
			//std::cout << dsv(min_pnt) << std::endl;
			
			
			///////////////////////////////
			///////////////////////////////
			///////////////////////////////
			x1_tr = (x1-cpx)*cos(cpo) + (y1-cpy)*sin(cpo);
			y1_tr = -(x1-cpx)*sin(cpo) + (y1-cpy)*cos(cpo);
			
			if (dmin <= Q_star)
			{
				d_u_rep_x = eta2 * (1/Q_star - 1/dmin) / pow(dmin,2) * (yb_x[yi]-x1_tr); 
				d_u_rep_y =	eta2 * (1/Q_star - 1/dmin) / pow(dmin,2) * (yb_y[yi]-y1_tr);
			}
			else
			{
				d_u_rep_x = 0.0;
				d_u_rep_y = 0.0;
			}
			d_u_rep_t = -d_u_rep_x *(yb_x[yi]*sin(cpo)+yb_y[yi]*cos(cpo)) + d_u_rep_y * (yb_x[yi]*cos(cpo)-yb_y[yi]*sin(cpo));

			//std::cout << cpx << " " << cpy << " " << pgx << " " << pgy << " " <<  d_rq_rqg << " " << d_u_att_x << " " << d_u_att_y << std::endl;
			vel.linear.x += (d_u_rep_x + d_u_att_x);
			vel.linear.y += (d_u_rep_y + d_u_att_y);
			vel.angular.z += (d_u_rep_t + d_u_att_t);
			//vel.linear.x = d_u_att_x;
			//vel.linear.y = d_u_att_y;
		}
		//std::cout << d_u_rep_x << std::endl;
		std::cout << cpo << " " << cpo / 3.14 * 180 << " " << pgx_tr << " " << pgy_tr << std::endl; 
		//std::cout << "dist: " << std::setprecision(3) << dmin << " " << 
		//"loc(x,y): (" << std::setprecision(3) << x1 << "," << std::setprecision(3) << y1 << ") " << "err(x,y): (" << std::setprecision(3) << pgx - cpx << "," << std::setprecision(3) << pgy - cpy << ")"<< std::endl;
		pub.publish(vel);
		loop_rate.sleep();
	}

	return 0;
}





